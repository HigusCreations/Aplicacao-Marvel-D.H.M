<!DOCTYPE html>

<html lang="en">

    
    <head>

        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">

        <!-- PARDRÃO RESPONSIVO -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
         integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        
        <title>D.H.M</title>

        <link rel="stylesheet" href="style.css">

    </head>
    
    <body onload="character()"> <!-- Carrega função JS "character()" -->

        <!--SEÇÃO DE PESQUISA DIV-->
        <div class="jumbotron">

            <!--ÁREA DE PESQUISA-->
            <div class="container">

                <h1 class="DHM">D.H.M</h1>
                <h2 class="short-title">Departamento de Heróis Marvel</h2>

                <h4 class="header-main-title">Busque o herói que você precisa:</h4>
                
                <!--FORMULÁRIO DE PESQUISA-->
                <form id="connectionForm">

                    <div class="form-group">

                        <!--CAIXA DE PESQUISA-->
                        <input required type="text" name="name" id="name" class="form-control character-search-box" 
                         placeholder="(Ex. Hulk, Sub-Mariner, Rage, Wolverine etc...)">

                    </div>

                    <!--BOTÃO DE PESQUISA-->
                    <input type="submit" value="Pesquisar" class="btn btn-danger mb-2 float-right search-character-button">

                </form>
                <!--FORMULÁRIO DE PESQUISA-->

            </div>
            <!--ÁREA DE PESQUISA-->

        </div>
        <!--SEÇÃO DE PESQUISA DIV-->

        <!--ÁREA DOS PERSONAGENS E QUADRINHOS-->
        <div class="container" id="contentContainer">

            <div class="d-flex align-items-center" id="characterSpinnerSection"></div>
            <div class="d-flex align-items-center" id="comicsSpinnerSection"></div> 

            <section id="characterSection"></section>
            <section id="comicSection"></section>

        </div>
        <!--ÁREA DOS PERSONAGENS E QUADRINHOS-->
 
        <script src="main.js"></script>

        <!-- Bootstrap, JS, POPPER -->
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
         integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
        </script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
         integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
        </script>

        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
         integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
        </script>

    </body>

</html>